package ru.ironcodes.islamicwikipedia.utilities;


public class Data {
    String subject,link;

    public Data(String tt1, String tt2) {
        this.subject = tt1;
        this.link = tt2;
    }


    public String getSubject() {
        return this.subject;
    }

    public String getLink() {
        return this.link;
    }



}



